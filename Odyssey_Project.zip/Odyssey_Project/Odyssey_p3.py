# initialize
import time
import sys
import textwrap
import os
delayTime = 0.001
tick = False
tales = False
devMode = False
path = ""
npcList = []
npcListInit = []

# Location List
southGateGraph = [2,3]
southGateAccess = ['market']
southGateItems = []
southGateNPCs = []

marketGraph = [3,4]
marketAccess = ['south gate','temple','armory','south gate','west gate','east gate']
marketItems = ['orange']
marketNPCs = []

templeGraph = [8,9]
templeAccess = ['altar','belfry','market']
templeItems = []
templeNPCs = []

altarGraph = [9,10]
altarAccess = ['market','belfry','temple']
altarItems = ['gold','candle','bell','book']
altarNPCs = []

belfryGraph = [16,17]
belfryAccess = ['temple']
belfryItems = []
belfryNPCs = []

armoryGraph = [18,19]
armoryAccess = ['market']
armoryItems = ['spear','axe','bow','shield','armor','map','key']
armoryNPCs = []

westGateGraph = [19,20]
westGateAccess = ['market']
westGateItems = []
westGateNPCs = []

eastGateGraph = [17,18]
eastGateAccess = ['market']
eastGateItems = []
eastGateNPCs = []

seaGraph = [26,27]
seaAccess = []
seaItems = []
seaNPCs = []

noneGraph = []
noneAccess = ['east gate']
noneItems = []
noneNPCs = []

southGateData = { 'npcs' : southGateNPCs , 'graph' : southGateGraph , 'access' : southGateAccess , 'items' : southGateItems }
marketData = { 'npcs' : marketNPCs , 'graph' : marketGraph , 'access' : marketAccess , 'items' : marketItems }
templeData = { 'npcs' : templeNPCs , 'graph' : templeGraph , 'access' : templeAccess , 'items' : templeItems }
belfryData = { 'npcs' : belfryNPCs , 'graph' : belfryGraph , 'access' : belfryAccess , 'items' : belfryItems }
armoryData = { 'npcs' : armoryNPCs , 'graph' : armoryGraph , 'access' : armoryAccess , 'items' : armoryItems }
westGateData = { 'npcs' : westGateNPCs , 'graph' : westGateGraph , 'access' : westGateAccess , 'items' : westGateItems }
eastGateData = { 'npcs' : eastGateNPCs , 'graph' : eastGateGraph , 'access' : eastGateAccess , 'items' : eastGateItems }
seaData = { 'npcs' : seaNPCs , 'graph' : seaGraph , 'access' : seaAccess , 'items' : seaItems }
noneData = {'npcs':noneNPCs,'graph':noneGraph,'access':noneAccess,'items':noneItems}
altarData = {'npcs':altarNPCs,'graph':altarGraph,'access':altarAccess,'items':altarItems}

locList = { 'south gate' : southGateData , 'market' : marketData , 'temple' : templeData , 'armory' : armoryData, \
            'west gate' : westGateData , 'east gate' : eastGateData , 'sea' : seaData , 'belfry' : belfryData \
            ,'none' : noneData , 'altar' : altarData}

# Other Lists
weaponList = {'sword' : 2 , 'spear' : 1 , 'axe' : 3 , 'staff' : 1 }
armorList = {'veil' : 5 , 'armor' : 1 , 'shield' : 1}
commandList = ['look','get','equip','use','unequip','drop','throw','inventory','help','[name of an NPC, item, or location]']

# TEXT FUNCTIONS ==========================================================================================================================
def process_file(filename):
    file = open(filename, encoding='utf-8')
    textFile = file.readlines()
    return textFile

def delay_print(textFile,start,stop):
    word_list = []
    wrapper = textwrap.TextWrapper(width=70)

    for i in textFile:
        if i != '\n':
        #and i[0:2] != "//":
            line = wrapper.wrap(text=i)
            word_list.append(line)
        
    p = start
    l = 0
    c = 0

    while p in range(start,stop):
        print()
        while l < len(word_list[p]):
            while c < len(word_list[p][l]):
                sys.stdout.write(word_list[p][l][c])
                sys.stdout.flush()
                time.sleep(delayTime)
                c+=1
            print()
            c=0
            l+=1
        l=0
        p+=1
        if p in range(start,stop): input('\n...')
        else: print()

def capitalize(word):
    firstLetter = word[0]
    capitalLetter = firstLetter.upper()
    return word.replace(firstLetter,capitalLetter,1)

def restart_program():
    """Restarts the current program.
    Note: this function does not return. Any cleanup action (like
    saving data) must be done before calling this function.
    Note: When run in IDLE, this function will quit, but not restart
    the program. It will restart the program when run in the terminal."""
    python = sys.executable
    os.execl(python, python, * sys.argv)

# PLAYER OBJECT =====================================================================================================
class Player:
    
    def __init__(self, hp, defense, current_location, inventory, equipmentList):   
        self.name = 'me'
        self.hp = hp
        self.defense = defense
        self.current_location = current_location
        self.inventory = inventory
        self.equipmentList = equipmentList
        self.equipmentCount = 0
        
    def damage(self, value):
        for item in self.equipmentList:
            if item in armorList:
                self.defense = armorList[item]
                
        value = max(value-self.defense,0)
        self.hp -= value
        print("-"+str(value)+" HP")
        print("HP"+" = "+str(self.hp))

        if self.hp <= 0:
            print("Ulysses Died\nGAME OVER\n")
            print('='*70)
            print()
            restart_program()
        
    def heal(self, hp, value):
        self.hp += value
        print("+"+str(value)+" HP")
        print("HP"+" = "+str(self.hp))

    def use(self,textFile):
        global tick
        item = input('Use what? ')
        if item in self.equipmentList:
            if item in weaponList:
                target = eval(input('Target: '))
                target.damage(textFile, weaponList[item])
            tick = True
        elif item in self.inventory:
            if item == 'bell':
                if self.current_location == 'belfry':
                    delay_print(textFile,17,18)
            elif item == 'key':
                if self.current_location == 'west gate':
                    delay_print(textFile,27,28)
                    ismarus_4()
            elif item in armorList:
                print('Use "equip".')
        else:
            print("I don't know this word")

    def get(self, textFile, locItems):
        item = input("Get what? ")
        if item in locItems:
            self.get_item(textFile, locItems, item)
        else:
            print("I don't know this word.")

    def get_item(self, textFile, locItems, item):
        global tick
        global locList
        self.inventory.append(item)
        if item in locItems:
            locItems.remove(item)
        print(item+' added to inventory.')
        
        if len(locList['altar']['items']) == 0:
              locList['altar']['graph'] = [10,11]
        if self.current_location == 'market' and 'gold' not in locItems:
            delay_print(textFile,6,7)
        
        tick = True

    def equip(self):
        global tick
        item = input('Equip what? ')
        if item in self.inventory:
            self.get_equipmentCount()
            # armor: 0 handed
            # if equipping armor
            if item in armorList:
                itemWeight = 0
                # & other armor already equipped, de-equip other armor
                for equipped_item in self.equipmentList:
                    if equipped_item in armorList:
                        print(equipped_item+" removed")
                        self.equipmentList.remove(equipped_item)
                        self.inventory.append(equipped_item)
                        print(equipped_item+" placed in inventory.")
                # set defense
                self.defense = armorList[item]
            # weapons: one or two-handed?
            elif item == 'bow':
                itemWeight = 2
            else:
                itemWeight = 1

            # if hands available, equip item
            if itemWeight + self.equipmentCount > 2:
                print("Maximum items already equipped. Drop or unequip items to equip others.")
            else:
                self.equipmentList.append(item)
                self.equipmentCount += itemWeight
                print(item+" equipped.")
                self.inventory.remove(item)
                tick = True
        else:
            print("I don't know this word")
        
    def unequip(self):
        global tick
        item = input('Unequip what? ')
        if item in self.equipmentList:
            self.equipmentList.remove(item)
            self.inventory.append(item)
            tick = True
        else:
            print("I don't know that word.")

    def drop(self):
        global tick
        item = input('Drop what? ')
        if item in self.equipmentList:
            self.equipmentList.remove(item)
            locList[self.current_location]['items'].append(item)
            print("Dropped "+item)
            tick = True
        elif item in self.inventory:
            self.inventory.remove(item)
            locList[self.current_location]['items'].append(item)
            print("Dropped "+item)
            tick = True
        else:
            print("You don't have that item.")

    def throw(self):
        global tick
        item = input('Throw what? ')
        if item in self.equipmentList:
            self.equipmentList.remove(item)
            locList[self.current_location]['items'].append(item)
            print("Threw "+item)
            tick = True
        elif item in self.inventory:
            self.inventory.remove(item)
            locList[self.current_location]['items'].append(item)
            print("Threw "+item)
            tick = True
        else:
            print("You don't have that item.")

    def get_equipmentCount(self):
        self.equipmentCount = 0
        for item in self.equipmentList:
            if item in armorList:
                self.equipmentCount += 0
            elif item == 'bow':
                self.equipmentCount += 2
            else:
                self.equipmentCount += 1

    def show_inventory(self):
        print('INVENTORY')
        for item in self.inventory:
            print(" -"+item)
        print('EQUIPPED')
        for item in self.equipmentList:
            print(" -"+item)

    def show_stats(self):
        print("HP"+" = "+str(self.hp))
        print("Defense"+" = "+str(self.defense))
        #print("Charisma"+" = "+self.charisma)

    def show_commands(self):
        print("COMMANDS")
        for command in commandList:
            print(" -"+command)

    def move(self, destination, textFile):
        global tick
        self.current_location = destination
        tick = True
        self.look(textFile)

    def look(self, textFile):
        locGraph = locList[self.current_location]["graph"]
        delay_print(textFile,locGraph[0],locGraph[1])
        global devMode
        if devMode == True:
            print("NPCs:")
            for npc in locList[self.current_location]["npcs"]:
                print(" -"+npc)
            print("Items:")
            for item in locList[self.current_location]["items"]:
                print(" -"+item)
            print("Locations:")
            for access in locList[self.current_location]["access"]:
                print(" -"+access)
            print()

    def npc_interaction(self, textFile, locItems, targetName):
        global tick
        target = eval(targetName)
        delay_print(textFile,target.text[0],target.text[1])
        commandNPC = input("Do what to "+targetName+"? ")

        # Give            
        if commandNPC == 'give':
            item = input('Give what? ')
            if item in self.equipmentList:
                self.equipmentList.remove(item)
                target.get(item)
                print("Gave "+command+' '+item+'.')
                tick = True
            elif item in self.inventory:
                self.inventory.remove(item)
                target.get(item)
                print("Gave "+targetName+' '+item+'.')
                tick = True
            else:
                print("You don't have that item.")

        # Attack            
        elif commandNPC == 'attack':
            damage = 0
            for item in self.equipmentList:
                if item in weaponList:
                    damage += weaponList[item]
            if damage > 0:
                target.damage(textFile, damage)
                tick = True

        # Speak                
        elif commandNPC == 'speak':
            target.speak(textFile, locItems)
            
        # Non Gameplay
        elif commandNPC == 'inventory':
            target.show_inventory()
        elif commandNPC == 'stats':
            target.show_stats()                 
        elif commandNPC != '':
            print("I don't know that word. (action to NPC)")
            
    def command(self, command, textFile):
        textFile = process_file("Odyssey_Ismarus_1.txt")
        locAccess = locList[self.current_location]["access"]
        locNPCs = locList[self.current_location]["npcs"]
        locItems = locList[self.current_location]["items"]

        if command == 'use':
            self.use(textFile)
        elif command == 'look':
            self.look(textFile)
        elif command == 'get':
            self.get(textFile, locItems)
        elif command == 'equip':
            self.equip()
        elif command == 'unequip':
            self.unequip()
        elif command == 'drop':
            self.drop()
        elif command == 'throw':
            self.throw()
        elif command == 'inventory':
            self.show_inventory()
        elif command == 'stats':
            self.show_stats()
        elif command == 'help':
            self.show_commands()   
        elif command in locNPCs:
            self.npc_interaction(textFile, locItems, command)     
        elif command == 'npcList':
            for npc in npcList:
                target = eval(npc)
                target.show_location()
        elif command == 'menu' or command == 'restart' or command == 'quit':
            restart_program()

        elif command in locAccess:
            self.move(command, textFile)
        elif command in locList:
            print("You can't get there from here.")
        elif command in locItems:
            self.get_item(textFile, locItems, command)

        elif command == 'climb' and self.current_location == 'west gate':
            delay_print(textFile,28,29)
            ismarus_4()

# NPC SUPERCLASS=====================================================================================================
class NPC:

    def __init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText):
        self.quantity = int(quantity)
        self.name = name
        self.hp = hp
        self.defense = defense
        self.current_location = current_location
        self.inventory = inventory
        self.equipmentList = equipmentList
        self.text = text
        self.deathText = deathText
        for i in range(quantity):
            locList[current_location]['npcs'].append(name)
            npcList.append(name)
        
    def heal(self, value):
        self.hp += value

    def damage(self, textFile, value):
        self.hp -= value
        print('\n'+self.name+' took '+str(value)+' damage.')
        if self.hp <= 0:
            self.death(textFile)

    def death(self, textFile):
        print(self.name+' died.')
        print(self.name+' dropped:')
        for item in self.inventory:
            print(" -"+item)
            locList[self.current_location]['items'].append(item)
        for item in self.equipmentList:
            print(" -"+item)
            locList[self.current_location]['items'].append(item)
        locList[self.current_location]['npcs'].remove(self.name)
        npcList.remove(self.name)
        delay_print(textFile,self.deathText[0],self.deathText[1])
               
    #def use(self, item):

    def move(self, location):
        locAccess = locList[self.current_location]["access"]
        if location in locAccess:
            locList[self.current_location]['npcs'].remove(self.name)
            self.current_location = location
            locList[self.current_location]['npcs'].append(self.name)

    def speak(self, textFile, locItems):
        print("They say nothing.")

    def get(self, item):
        self.inventory.append(item)

    def show_inventory(self):
        print('INVENTORY')
        for item in self.inventory:
            print(" -"+item)
        print('EQUIPPED')
        for item in self.equipmentList:
            print(" -"+item)
    def show_stats(self):
        print("HP"+" = "+str(self.hp))
        print("Defense"+" = "+str(self.defense))
    def show_location(self):
        print(self.name+' - '+self.current_location)
    def get_name(self):
        return self.name
    def get_display_name(self):
        return self.display_name


    # NPC SUBCLASSES

class Soldier(NPC):
    def __init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText):
        NPC.__init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText)

    def attack(self, target):
        damage = 0
        for item in self.equipmentList:
            if item in weaponList:
                if item == 'sword':
                    damage += 2
                elif item == 'spear':
                    damage += 1
                elif item == 'axe':
                    damage += 3
        if damage > 0:
            target.damage(damage)
        print('A soldier attacked '+target.name+'.')
        
class Maron(NPC):

        def __init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText):
            NPC.__init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText)

        def speak(self, textFile, locItems):
            global tick
            delay_print(textFile,13,14)
            if input('Spare? (y/n): ') == 'y':
                delay_print(textFile,14,15)
                print()
                myPlayer.get_item(textFile, locItems, 'gold')
                myPlayer.get_item(textFile, locItems, 'silver')
                myPlayer.get_item(textFile, locItems, 'wine')
                print()
    

# CHAPTERS ==============================================================
# PROLOGUE
def prologue():
    textFile = process_file("Odyssey_Prologue_1.txt")
    print("---PROLOGUE---")
    delay_print(textFile,0,5)
    # SEA
    def sceneOne():
            command = input()
            myPlayer.command(command, textFile)
            if command == 'look':
                delay_print(textFile,4,5)
                sceneOne()
            elif command == 'swim':
                delay_print(textFile,5,6)
                myPlayer.damage(1)
                sceneOne()
            elif command == 'sail' or command == 'raft' or command == 'ship':
                delay_print(textFile,6,9)
                myPlayer.inventory.append('veil')
                print("Veil of Ino added to inventory\n")
                sceneTwo()
            else:
                sceneOne()
            
    # RAFT
    def sceneTwo():
        pray = False
        command = input('')
        myPlayer.command(command, textFile)
        if command == 'swim':
            delay_print(textFile,11,15)
            sceneThree()
        elif command == 'sail':
            delay_print(textFile,9,11)
            myPlayer.damage(1)
            delay_print(textFile,11,15)
            sceneThree()
        elif command == 'pray':
            if pray == False:
                pray()
                pray = True
                sceneTwo()
        else:
            sceneTwo()
        
    # OFF COAST
    def sceneThree():
        command = input('')
        myPlayer.command(command, textFile)
        if command == 'coast':
            delay_print(textFile,15,16)
            myPlayer.damage(1)
            sceneThree()
        elif command == 'swim':
            delay_print(textFile,16,18)
        elif command != 'swim':
            sceneThree()
        sceneFour()
    # RIVERBED
    def sceneFour():
        command = input('')
        myPlayer.command(command, textFile)
        if command == 'river':
            delay_print(textFile,18,19)
            myPlayer.damage(1)
            delay_print(textFile,19,20)
            print("---PROLOGUE COMPLETE---")
            phaeacia()
        elif command == 'woods':
            delay_print(textFile,20,21)
            print("---PROLOGUE COMPLETE---")
            phaeacia()
        else:
            sceneFour()
        
    # PRAYER
    def pray():
        print('He felt that there was a current, so he prayed inwardly and said:')
        pray = input("Pray for what?")
        if pray == 'health':
            myPlayer.heal(1)
        elif pray == 'wind':
            myPlayer.inventory.append('Bag of Winds')
            print("Bag of Winds added to inventory")
        else:
            pray()
    sceneOne()

#CHAPTER 1: PHAEACIA
def phaeacia():
    textFile = process_file("Odyssey_Phaeacia.txt")
    hospitality = ['hospitality','pray','plead','beg']
    demand = ['demand','strength','warrior']
    charm = ['charm','persuade','honor','appeal','praise','humor']
    truthName = ['truth','Odysseus','Ulysses']
    truthHome = ['truth','Ithaca']
    print("---CHAPTER ONE: PHAEACIA---")
    delay_print(textFile,0,2)
    #GROVE
    def scenePOne():
        input('...')
        delay_print(textFile,2,3)
        command = input('')
        if command == 'pray':
            delay_print(textFile,5,16)
            scenePTwo()
        elif command == 'rest' or command == 'sleep':
            delay_print(textFile,3,5)
            scenePOne()
        else:
            scenePOne()
    #PETITION
    def scenePTwo():
        command = input('Petition: ')
        if command in hospitality:
            delay_print(textFile,16,17)
            scenePThree()
        elif command in demand:
            delay_print(textFile,17,19)
            scenePOne()
        elif command in charm:
            delay_print(textFile,19,20) 
            scenePThree()
        else:
            scenePTwo()
    def scenePThree():
        #NAME
        input('...')
        delay_print(textFile,20,21)
        def scenePThreeAnswer():
            command = input('Answer: ')
            if command in truthName:
                delay_print(textFile,21,24)
                scenePThreeHome()
            elif command != '':
                delay_print(textFile,21,22)
                input('...')
                command = capitalize(command)
                print('I am '+command+', renowned among mankind for all manner of subtlety,\nso that my fame ascends to heaven.\n') 
                input('...')
                delay_print(textFile,23,24)
                scenePThreeHome()
            else:
                scenePThreeAnswer()
        #HOME
        def scenePThreeHome():
            command = input('Answer: ')
            if command in truthHome:
                delay_print(textFile,24,26)
            elif command != '':
                command = capitalize(command)
                print('\nI live in '+command+', and I have been far from it for far too long.\n')
                input('...')
                delay_print(textFile,25,26)
                scenePThreeQuest()
            else:
                scenePThreeHome()
        #QUEST
        def scenePThreeQuest():
            global tales
            while tales != 'truth' and tales != 'fiction':
                tales = input('Truth / Fiction: ')
            delay_print(textFile,26,27)
            print('---CHAPTER ONE: PHAEACIA COMPLETE----')
            ismarus()
        scenePThreeAnswer()
    scenePOne()
        
def ismarus():
    textFile = process_file("Odyssey_Ismarus_1.txt")
    print("---CHAPTER TWO: ISMARUS---")
    delay_print(textFile,0,3)

    myPlayer.__init__(5, 0, 'south gate', [], ['sword'])

    # Pre-Soldiers
    def ismarus_1():
        global tick
        tick = False
        command = input('')
        myPlayer.command(command, textFile)

        if tick == True:
            if myPlayer.current_location == 'temple' \
            or myPlayer.current_location == 'armory' \
            or myPlayer.current_location == 'east gate':
                ismarus_2()
            else:
                ismarus_1()
        else:
            ismarus_1()

    # Soldiers Incoming
    def ismarus_2():
        global tick
        tick = False
        command = input('')
        myPlayer.command(command, textFile)

        locList['south gate']['graph'] = [23,24]
        locList['east gate']['graph'] = [25,26]
        locList['west gate']['graph'] = [26,27]

        if tick == True:
            if myPlayer.current_location == 'belfry' \
            or myPlayer.current_location == 'market' \
            or myPlayer.current_location == 'east gate':
                input('...')
                delay_print(textFile,22,23)                 # soldier alert
                soldier.move('east gate')
                print('Soldiers flood the '+soldier.current_location+'.'+'\n')
                ismarus_3()
            else:
                ismarus_2()
        else:
            ismarus_2()

    # Soldiers Arrive
    def ismarus_3():
        global tick
        tick = False
        command = input('')
        myPlayer.command(command, textFile)

        locList['market']['graph'] = [24,25]

        if tick == True:
            if soldier.current_location == myPlayer.current_location:
                soldier.attack(myPlayer)
            if myPlayer.current_location in locList[soldier.current_location]["access"]:
                soldier.move(myPlayer.current_location)
            else:
                soldier.move('market')
            print('Soldiers flood the '+soldier.current_location+'.'+'\n')

        if myPlayer.current_location == 'south gate' or myPlayer.current_location == 'east gate':
            ismarus_4()
        
        ismarus_3()

    # Leave Ismarus
    def ismarus_4():
        delay_print(textFile,31,32)
        ismarus_5()
    # Sea
    def ismarus_5():
        command = input('')
        if command == 'sail':
            delay_print(textFile,32,33)
            print("---CHAPTER TWO: ISMARUS COMPLETE---")
            restart_program()
        elif command == 'row':
            delay_print(textFile,33,35)
            print("---CHAPTER TWO: ISMARUS COMPLETE---")
            restart_program()
        elif command == 'pray':
            delay_print(textFile,35,36)
            input('...')
            delay_print(textFile,34,35)
            print("---CHAPTER TWO: ISMARUS COMPLETE---")
            restart_program()
        else:
            ismarus_5()
            
    ismarus_1()
    

# MAIN ------------------------------------------------------------
def main():
    print('ALL COMMANDS MUST BE LOWERCASE')
    print('COMMON COMMANDS\n -use\n -look\n -get\n -equip\n -unequip'+\
          '\n -drop\n -throw\n -inventory\n -help\n -Location Name'+\
          '\n -NPC Name\n -Item Name\n -sail\n -swim\n -pray\n -climb'+\
          '\n -attack\n -speak\n')
    print('Chapters: Prologue, Phaeacia, Ismarus')
    chapter = input('Choose chapter: ')
    print('')
    if chapter == 'prologue':
        prologue()
    elif chapter == 'phaeacia':
        phaeacia()
    elif chapter == 'ismarus':
        ismarus()
    else:
        main()
    main()

# Objects
myPlayer = Player(5, 0, 'none', [], [])
myPlayer.get_equipmentCount()
cicons = NPC(1, 'cicons' , 1 , 0, "market", ['gold'], [], [4,5], [5,6])
maron = Maron(1,'maron',1,0,'temple',[],[],[11,12],[15,16])
soldier = Soldier(1,'soldier',2,2,'none',[],['spear','shield','armor'],[12,13],[-2,-1])

main()
