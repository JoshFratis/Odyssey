# initialize
from __future__ import absolute_import
import time
import sys
import textwrap
import os
from io import open
delayTime = 0.001
tick = False
tales = False
devMode = False
path = u""
npcList = []
npcListInit = []

# Location List
southGateGraph = [2,3]
southGateAccess = [u'market']
southGateItems = []
southGateNPCs = []

marketGraph = [3,4]
marketAccess = [u'south gate',u'temple',u'armory',u'south gate',u'west gate',u'east gate']
marketItems = [u'orange']
marketNPCs = []

templeGraph = [8,9]
templeAccess = [u'altar',u'belfry',u'market']
templeItems = []
templeNPCs = []

altarGraph = [9,10]
altarAccess = [u'market',u'belfry',u'temple']
altarItems = [u'gold',u'candle',u'bell',u'book']
altarNPCs = []

belfryGraph = [16,17]
belfryAccess = [u'temple']
belfryItems = []
belfryNPCs = []

armoryGraph = [18,19]
armoryAccess = [u'market']
armoryItems = [u'spear',u'axe',u'bow',u'shield',u'armor',u'map',u'key']
armoryNPCs = []

westGateGraph = [19,20]
westGateAccess = [u'market']
westGateItems = []
westGateNPCs = []

eastGateGraph = [17,18]
eastGateAccess = [u'market']
eastGateItems = []
eastGateNPCs = []

seaGraph = [26,27]
seaAccess = []
seaItems = []
seaNPCs = []

noneGraph = []
noneAccess = [u'east gate']
noneItems = []
noneNPCs = []

southGateData = { u'npcs' : southGateNPCs , u'graph' : southGateGraph , u'access' : southGateAccess , u'items' : southGateItems }
marketData = { u'npcs' : marketNPCs , u'graph' : marketGraph , u'access' : marketAccess , u'items' : marketItems }
templeData = { u'npcs' : templeNPCs , u'graph' : templeGraph , u'access' : templeAccess , u'items' : templeItems }
belfryData = { u'npcs' : belfryNPCs , u'graph' : belfryGraph , u'access' : belfryAccess , u'items' : belfryItems }
armoryData = { u'npcs' : armoryNPCs , u'graph' : armoryGraph , u'access' : armoryAccess , u'items' : armoryItems }
westGateData = { u'npcs' : westGateNPCs , u'graph' : westGateGraph , u'access' : westGateAccess , u'items' : westGateItems }
eastGateData = { u'npcs' : eastGateNPCs , u'graph' : eastGateGraph , u'access' : eastGateAccess , u'items' : eastGateItems }
seaData = { u'npcs' : seaNPCs , u'graph' : seaGraph , u'access' : seaAccess , u'items' : seaItems }
noneData = {u'npcs':noneNPCs,u'graph':noneGraph,u'access':noneAccess,u'items':noneItems}
altarData = {u'npcs':altarNPCs,u'graph':altarGraph,u'access':altarAccess,u'items':altarItems}

locList = { u'south gate' : southGateData , u'market' : marketData , u'temple' : templeData , u'armory' : armoryData, \
            u'west gate' : westGateData , u'east gate' : eastGateData , u'sea' : seaData , u'belfry' : belfryData \
            ,u'none' : noneData , u'altar' : altarData}

# Other Lists
weaponList = {u'sword' : 2 , u'spear' : 1 , u'axe' : 3 , u'staff' : 1 }
armorList = {u'veil' : 5 , u'armor' : 1 , u'shield' : 1}
commandList = [u'look',u'get',u'equip',u'use',u'unequip',u'drop',u'throw',u'inventory',u'help',u'[name of an NPC, item, or location]']

# TEXT FUNCTIONS ==========================================================================================================================
def process_file(filename):
    file = open(filename, encoding=u'utf-8')
    textFile = file.readlines()
    return textFile

def delay_print(textFile,start,stop):
    word_list = []
    wrapper = textwrap.TextWrapper(width=70)

    for i in textFile:
        if i != u'\n':
        #and i[0:2] != "//":
            line = wrapper.wrap(text=i)
            word_list.append(line)
        
    p = start
    l = 0
    c = 0

    while p in xrange(start,stop):
        print
        while l < len(word_list[p]):
            while c < len(word_list[p][l]):
                sys.stdout.write(word_list[p][l][c])
                sys.stdout.flush()
                time.sleep(delayTime)
                c+=1
            print
            c=0
            l+=1
        l=0
        p+=1
        if p in xrange(start,stop): raw_input(u'\n...')
        else: print

def capitalize(word):
    firstLetter = word[0]
    capitalLetter = firstLetter.upper()
    return word.replace(firstLetter,capitalLetter,1)

def restart_program():
    u"""Restarts the current program.
    Note: this function does not return. Any cleanup action (like
    saving data) must be done before calling this function.
    Note: When run in IDLE, this function will quit, but not restart
    the program. It will restart the program when run in the terminal."""
    python = sys.executable
    os.execl(python, python, * sys.argv)

# PLAYER OBJECT =====================================================================================================
class Player(object):
    
    def __init__(self, hp, defense, current_location, inventory, equipmentList):   
        self.name = u'me'
        self.hp = hp
        self.defense = defense
        self.current_location = current_location
        self.inventory = inventory
        self.equipmentList = equipmentList
        self.equipmentCount = 0
        
    def damage(self, value):
        for item in self.equipmentList:
            if item in armorList:
                self.defense = armorList[item]
                
        value = max(value-self.defense,0)
        self.hp -= value
        print u"-"+unicode(value)+u" HP"
        print u"HP"+u" = "+unicode(self.hp)

        if self.hp <= 0:
            print u"Ulysses Died\nGAME OVER\n"
            print u'='*70
            print
            restart_program()
        
    def heal(self, hp, value):
        self.hp += value
        print u"+"+unicode(value)+u" HP"
        print u"HP"+u" = "+unicode(self.hp)

    def use(self,textFile):
        global tick
        item = raw_input(u'Use what? ')
        if item in self.equipmentList:
            if item in weaponList:
                target = eval(raw_input(u'Target: '))
                target.damage(textFile, weaponList[item])
            tick = True
        elif item in self.inventory:
            if item == u'bell':
                if self.current_location == u'belfry':
                    delay_print(textFile,17,18)
            elif item == u'key':
                if self.current_location == u'west gate':
                    delay_print(textFile,27,28)
                    ismarus_4()
            elif item in armorList:
                print u'Use "equip".'
        else:
            print u"I don't know this word"

    def get(self, textFile, locItems):
        item = raw_input(u"Get what? ")
        if item in locItems:
            self.get_item(textFile, locItems, item)
        else:
            print u"I don't know this word."

    def get_item(self, textFile, locItems, item):
        global tick
        global locList
        self.inventory.append(item)
        if item in locItems:
            locItems.remove(item)
        print item+u' added to inventory.'
        
        if len(locList[u'altar'][u'items']) == 0:
              locList[u'altar'][u'graph'] = [10,11]
        if self.current_location == u'market' and u'gold' not in locItems:
            delay_print(textFile,6,7)
        
        tick = True

    def equip(self):
        global tick
        item = raw_input(u'Equip what? ')
        if item in self.inventory:
            self.get_equipmentCount()
            # armor: 0 handed
            # if equipping armor
            if item in armorList:
                itemWeight = 0
                # & other armor already equipped, de-equip other armor
                for equipped_item in self.equipmentList:
                    if equipped_item in armorList:
                        print equipped_item+u" removed"
                        self.equipmentList.remove(equipped_item)
                        self.inventory.append(equipped_item)
                        print equipped_item+u" placed in inventory."
                # set defense
                self.defense = armorList[item]
            # weapons: one or two-handed?
            elif item == u'bow':
                itemWeight = 2
            else:
                itemWeight = 1

            # if hands available, equip item
            if itemWeight + self.equipmentCount > 2:
                print u"Maximum items already equipped. Drop or unequip items to equip others."
            else:
                self.equipmentList.append(item)
                self.equipmentCount += itemWeight
                print item+u" equipped."
                self.inventory.remove(item)
                tick = True
        else:
            print u"I don't know this word"
        
    def unequip(self):
        global tick
        item = raw_input(u'Unequip what? ')
        if item in self.equipmentList:
            self.equipmentList.remove(item)
            self.inventory.append(item)
            tick = True
        else:
            print u"I don't know that word."

    def drop(self):
        global tick
        item = raw_input(u'Drop what? ')
        if item in self.equipmentList:
            self.equipmentList.remove(item)
            locList[self.current_location][u'items'].append(item)
            print u"Dropped "+item
            tick = True
        elif item in self.inventory:
            self.inventory.remove(item)
            locList[self.current_location][u'items'].append(item)
            print u"Dropped "+item
            tick = True
        else:
            print u"You don't have that item."

    def throw(self):
        global tick
        item = raw_input(u'Throw what? ')
        if item in self.equipmentList:
            self.equipmentList.remove(item)
            locList[self.current_location][u'items'].append(item)
            print u"Threw "+item
            tick = True
        elif item in self.inventory:
            self.inventory.remove(item)
            locList[self.current_location][u'items'].append(item)
            print u"Threw "+item
            tick = True
        else:
            print u"You don't have that item."

    def get_equipmentCount(self):
        self.equipmentCount = 0
        for item in self.equipmentList:
            if item in armorList:
                self.equipmentCount += 0
            elif item == u'bow':
                self.equipmentCount += 2
            else:
                self.equipmentCount += 1

    def show_inventory(self):
        print u'INVENTORY'
        for item in self.inventory:
            print u" -"+item
        print u'EQUIPPED'
        for item in self.equipmentList:
            print u" -"+item

    def show_stats(self):
        print u"HP"+u" = "+unicode(self.hp)
        print u"Defense"+u" = "+unicode(self.defense)
        #print("Charisma"+" = "+self.charisma)

    def show_commands(self):
        print u"COMMANDS"
        for command in commandList:
            print u" -"+command

    def move(self, destination, textFile):
        global tick
        self.current_location = destination
        tick = True
        self.look(textFile)

    def look(self, textFile):
        locGraph = locList[self.current_location][u"graph"]
        delay_print(textFile,locGraph[0],locGraph[1])
        global devMode
        if devMode == True:
            print u"NPCs:"
            for npc in locList[self.current_location][u"npcs"]:
                print u" -"+npc
            print u"Items:"
            for item in locList[self.current_location][u"items"]:
                print u" -"+item
            print u"Locations:"
            for access in locList[self.current_location][u"access"]:
                print u" -"+access
            print

    def npc_interaction(self, textFile, locItems, targetName):
        global tick
        target = eval(targetName)
        delay_print(textFile,target.text[0],target.text[1])
        commandNPC = raw_input(u"Do what to "+targetName+u"? ")

        # Give            
        if commandNPC == u'give':
            item = raw_input(u'Give what? ')
            if item in self.equipmentList:
                self.equipmentList.remove(item)
                target.get(item)
                print u"Gave "+command+u' '+item+u'.'
                tick = True
            elif item in self.inventory:
                self.inventory.remove(item)
                target.get(item)
                print u"Gave "+targetName+u' '+item+u'.'
                tick = True
            else:
                print u"You don't have that item."

        # Attack            
        elif commandNPC == u'attack':
            damage = 0
            for item in self.equipmentList:
                if item in weaponList:
                    damage += weaponList[item]
            if damage > 0:
                target.damage(textFile, damage)
                tick = True

        # Speak                
        elif commandNPC == u'speak':
            target.speak(textFile, locItems)
            
        # Non Gameplay
        elif commandNPC == u'inventory':
            target.show_inventory()
        elif commandNPC == u'stats':
            target.show_stats()                 
        elif commandNPC != u'':
            print u"I don't know that word. (action to NPC)"
            
    def command(self, command, textFile):
        textFile = process_file(u"Odyssey_Ismarus_1.txt")
        locAccess = locList[self.current_location][u"access"]
        locNPCs = locList[self.current_location][u"npcs"]
        locItems = locList[self.current_location][u"items"]

        if command == u'use':
            self.use(textFile)
        elif command == u'look':
            self.look(textFile)
        elif command == u'get':
            self.get(textFile, locItems)
        elif command == u'equip':
            self.equip()
        elif command == u'unequip':
            self.unequip()
        elif command == u'drop':
            self.drop()
        elif command == u'throw':
            self.throw()
        elif command == u'inventory':
            self.show_inventory()
        elif command == u'stats':
            self.show_stats()
        elif command == u'help':
            self.show_commands()   
        elif command in locNPCs:
            self.npc_interaction(textFile, locItems, command)     
        elif command == u'npcList':
            for npc in npcList:
                target = eval(npc)
                target.show_location()
        elif command == u'menu' or command == u'restart' or command == u'quit':
            restart_program()

        elif command in locAccess:
            self.move(command, textFile)
        elif command in locList:
            print u"You can't get there from here."
        elif command in locItems:
            self.get_item(textFile, locItems, command)

        elif command == u'climb' and self.current_location == u'west gate':
            delay_print(textFile,28,29)
            ismarus_4()

# NPC SUPERCLASS=====================================================================================================
class NPC(object):

    def __init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText):
        self.quantity = int(quantity)
        self.name = name
        self.hp = hp
        self.defense = defense
        self.current_location = current_location
        self.inventory = inventory
        self.equipmentList = equipmentList
        self.text = text
        self.deathText = deathText
        for i in xrange(quantity):
            locList[current_location][u'npcs'].append(name)
            npcList.append(name)
        
    def heal(self, value):
        self.hp += value

    def damage(self, textFile, value):
        self.hp -= value
        print u'\n'+self.name+u' took '+unicode(value)+u' damage.'
        if self.hp <= 0:
            self.death(textFile)

    def death(self, textFile):
        print self.name+u' died.'
        print self.name+u' dropped:'
        for item in self.inventory:
            print u" -"+item
            locList[self.current_location][u'items'].append(item)
        for item in self.equipmentList:
            print u" -"+item
            locList[self.current_location][u'items'].append(item)
        locList[self.current_location][u'npcs'].remove(self.name)
        npcList.remove(self.name)
        delay_print(textFile,self.deathText[0],self.deathText[1])
               
    #def use(self, item):

    def move(self, location):
        locAccess = locList[self.current_location][u"access"]
        if location in locAccess:
            locList[self.current_location][u'npcs'].remove(self.name)
            self.current_location = location
            locList[self.current_location][u'npcs'].append(self.name)

    def speak(self, textFile, locItems):
        print u"They say nothing."

    def get(self, item):
        self.inventory.append(item)

    def show_inventory(self):
        print u'INVENTORY'
        for item in self.inventory:
            print u" -"+item
        print u'EQUIPPED'
        for item in self.equipmentList:
            print u" -"+item
    def show_stats(self):
        print u"HP"+u" = "+unicode(self.hp)
        print u"Defense"+u" = "+unicode(self.defense)
    def show_location(self):
        print self.name+u' - '+self.current_location
    def get_name(self):
        return self.name
    def get_display_name(self):
        return self.display_name


    # NPC SUBCLASSES

class Soldier(NPC):
    def __init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText):
        NPC.__init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText)

    def attack(self, target):
        damage = 0
        for item in self.equipmentList:
            if item in weaponList:
                if item == u'sword':
                    damage += 2
                elif item == u'spear':
                    damage += 1
                elif item == u'axe':
                    damage += 3
        if damage > 0:
            target.damage(damage)
        print u'A soldier attacked '+target.name+u'.'
        
class Maron(NPC):

        def __init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText):
            NPC.__init__(self, quantity, name, hp, defense, current_location, inventory, equipmentList, text, deathText)

        def speak(self, textFile, locItems):
            global tick
            delay_print(textFile,13,14)
            if raw_input(u'Spare? (y/n): ') == u'y':
                delay_print(textFile,14,15)
                print
                myPlayer.get_item(textFile, locItems, u'gold')
                myPlayer.get_item(textFile, locItems, u'silver')
                myPlayer.get_item(textFile, locItems, u'wine')
                print
    

# CHAPTERS ==============================================================
# PROLOGUE
def prologue():
    textFile = process_file(u"Odyssey_Prologue_1.txt")
    print u"---PROLOGUE---"
    delay_print(textFile,0,5)
    # SEA
    def sceneOne():
            command = raw_input()
            myPlayer.command(command, textFile)
            if command == u'look':
                delay_print(textFile,4,5)
                sceneOne()
            elif command == u'swim':
                delay_print(textFile,5,6)
                myPlayer.damage(1)
                sceneOne()
            elif command == u'sail' or command == u'raft' or command == u'ship':
                delay_print(textFile,6,9)
                myPlayer.inventory.append(u'veil')
                print u"Veil of Ino added to inventory\n"
                sceneTwo()
            else:
                sceneOne()
            
    # RAFT
    def sceneTwo():
        pray = False
        command = raw_input(u'')
        myPlayer.command(command, textFile)
        if command == u'swim':
            delay_print(textFile,11,15)
            sceneThree()
        elif command == u'sail':
            delay_print(textFile,9,11)
            myPlayer.damage(1)
            delay_print(textFile,11,15)
            sceneThree()
        elif command == u'pray':
            if pray == False:
                pray()
                pray = True
                sceneTwo()
        else:
            sceneTwo()
        
    # OFF COAST
    def sceneThree():
        command = raw_input(u'')
        myPlayer.command(command, textFile)
        if command == u'coast':
            delay_print(textFile,15,16)
            myPlayer.damage(1)
            sceneThree()
        elif command == u'swim':
            delay_print(textFile,16,18)
        elif command != u'swim':
            sceneThree()
        sceneFour()
    # RIVERBED
    def sceneFour():
        command = raw_input(u'')
        myPlayer.command(command, textFile)
        if command == u'river':
            delay_print(textFile,18,19)
            myPlayer.damage(1)
            delay_print(textFile,19,20)
            print u"---PROLOGUE COMPLETE---"
            phaeacia()
        elif command == u'woods':
            delay_print(textFile,20,21)
            print u"---PROLOGUE COMPLETE---"
            phaeacia()
        else:
            sceneFour()
        
    # PRAYER
    def pray():
        print u'He felt that there was a current, so he prayed inwardly and said:'
        pray = raw_input(u"Pray for what?")
        if pray == u'health':
            myPlayer.heal(1)
        elif pray == u'wind':
            myPlayer.inventory.append(u'Bag of Winds')
            print u"Bag of Winds added to inventory"
        else:
            pray()
    sceneOne()

#CHAPTER 1: PHAEACIA
def phaeacia():
    textFile = process_file(u"Odyssey_Phaeacia.txt")
    hospitality = [u'hospitality',u'pray',u'plead',u'beg']
    demand = [u'demand',u'strength',u'warrior']
    charm = [u'charm',u'persuade',u'honor',u'appeal',u'praise',u'humor']
    truthName = [u'truth',u'Odysseus',u'Ulysses']
    truthHome = [u'truth',u'Ithaca']
    print u"---CHAPTER ONE: PHAEACIA---"
    delay_print(textFile,0,2)
    #GROVE
    def scenePOne():
        raw_input(u'...')
        delay_print(textFile,2,3)
        command = raw_input(u'')
        if command == u'pray':
            delay_print(textFile,5,16)
            scenePTwo()
        elif command == u'rest' or command == u'sleep':
            delay_print(textFile,3,5)
            scenePOne()
        else:
            scenePOne()
    #PETITION
    def scenePTwo():
        command = raw_input(u'Petition: ')
        if command in hospitality:
            delay_print(textFile,16,17)
            scenePThree()
        elif command in demand:
            delay_print(textFile,17,19)
            scenePOne()
        elif command in charm:
            delay_print(textFile,19,20) 
            scenePThree()
        else:
            scenePTwo()
    def scenePThree():
        #NAME
        raw_input(u'...')
        delay_print(textFile,20,21)
        def scenePThreeAnswer():
            command = raw_input(u'Answer: ')
            if command in truthName:
                delay_print(textFile,21,24)
                scenePThreeHome()
            elif command != u'':
                delay_print(textFile,21,22)
                raw_input(u'...')
                command = capitalize(command)
                print u'I am '+command+u', renowned among mankind for all manner of subtlety,\nso that my fame ascends to heaven.\n' 
                raw_input(u'...')
                delay_print(textFile,23,24)
                scenePThreeHome()
            else:
                scenePThreeAnswer()
        #HOME
        def scenePThreeHome():
            command = raw_input(u'Answer: ')
            if command in truthHome:
                delay_print(textFile,24,26)
            elif command != u'':
                command = capitalize(command)
                print u'\nI live in '+command+u', and I have been far from it for far too long.\n'
                raw_input(u'...')
                delay_print(textFile,25,26)
                scenePThreeQuest()
            else:
                scenePThreeHome()
        #QUEST
        def scenePThreeQuest():
            global tales
            while tales != u'truth' and tales != u'fiction':
                tales = raw_input(u'Truth / Fiction: ')
            delay_print(textFile,26,27)
            print u'---CHAPTER ONE: PHAEACIA COMPLETE----'
            ismarus()
        scenePThreeAnswer()
    scenePOne()
        
def ismarus():
    textFile = process_file(u"Odyssey_Ismarus_1.txt")
    print u"---CHAPTER TWO: ISMARUS---"
    delay_print(textFile,0,3)

    myPlayer.__init__(5, 0, u'south gate', [], [u'sword'])

    # Pre-Soldiers
    def ismarus_1():
        global tick
        tick = False
        command = raw_input(u'')
        myPlayer.command(command, textFile)

        if tick == True:
            if myPlayer.current_location == u'temple' \
            or myPlayer.current_location == u'armory' \
            or myPlayer.current_location == u'east gate':
                ismarus_2()
            else:
                ismarus_1()
        else:
            ismarus_1()

    # Soldiers Incoming
    def ismarus_2():
        global tick
        tick = False
        command = raw_input(u'')
        myPlayer.command(command, textFile)

        locList[u'south gate'][u'graph'] = [23,24]
        locList[u'east gate'][u'graph'] = [25,26]
        locList[u'west gate'][u'graph'] = [26,27]

        if tick == True:
            if myPlayer.current_location == u'belfry' \
            or myPlayer.current_location == u'market' \
            or myPlayer.current_location == u'east gate':
                raw_input(u'...')
                delay_print(textFile,22,23)                 # soldier alert
                soldier.move(u'east gate')
                print u'Soldiers flood the '+soldier.current_location+u'.'+u'\n'
                ismarus_3()
            else:
                ismarus_2()
        else:
            ismarus_2()

    # Soldiers Arrive
    def ismarus_3():
        global tick
        tick = False
        command = raw_input(u'')
        myPlayer.command(command, textFile)

        locList[u'market'][u'graph'] = [24,25]

        if tick == True:
            if soldier.current_location == myPlayer.current_location:
                soldier.attack(myPlayer)
            if myPlayer.current_location in locList[soldier.current_location][u"access"]:
                soldier.move(myPlayer.current_location)
            else:
                soldier.move(u'market')
            print u'Soldiers flood the '+soldier.current_location+u'.'+u'\n'

        if myPlayer.current_location == u'south gate' or myPlayer.current_location == u'east gate':
            ismarus_4()
        
        ismarus_3()

    # Leave Ismarus
    def ismarus_4():
        delay_print(textFile,31,32)
        ismarus_5()
    # Sea
    def ismarus_5():
        command = raw_input(u'')
        if command == u'sail':
            delay_print(textFile,32,33)
            print u"---CHAPTER TWO: ISMARUS COMPLETE---"
            restart_program()
        elif command == u'row':
            delay_print(textFile,33,35)
            print u"---CHAPTER TWO: ISMARUS COMPLETE---"
            restart_program()
        elif command == u'pray':
            delay_print(textFile,35,36)
            raw_input(u'...')
            delay_print(textFile,34,35)
            print u"---CHAPTER TWO: ISMARUS COMPLETE---"
            restart_program()
        else:
            ismarus_5()
            
    ismarus_1()
    

# MAIN ------------------------------------------------------------
def main():
    print u'ALL COMMANDS MUST BE LOWERCASE'
    print u'COMMON COMMANDS\n -use\n -look\n -get\n -equip\n -unequip'+\
          u'\n -drop\n -throw\n -inventory\n -help\n -Location Name'+\
          u'\n -NPC Name\n -Item Name\n -sail\n -swim\n -pray\n -climb'+\
          u'\n -attack\n -speak\n'
    print u'Chapters: Prologue, Phaeacia, Ismarus'
    chapter = raw_input(u'Choose chapter: ')
    print u''
    if chapter == u'prologue':
        prologue()
    elif chapter == u'phaeacia':
        phaeacia()
    elif chapter == u'ismarus':
        ismarus()
    else:
        main()
    main()

# Objects
myPlayer = Player(5, 0, u'none', [], [])
myPlayer.get_equipmentCount()
cicons = NPC(1, u'cicons' , 1 , 0, u"market", [u'gold'], [], [4,5], [5,6])
maron = Maron(1,u'maron',1,0,u'temple',[],[],[11,12],[15,16])
soldier = Soldier(1,u'soldier',2,2,u'none',[],[u'spear',u'shield',u'armor'],[12,13],[-2,-1])

main()
